 const Data=()=>{
 // a. declare array
    const name=[];
    
//b. add item 
    name.push("rohit");
    name.push("nikhil");
    name.push("Ram");
    
//c. delete an item
    name.pop();
    
//d. add a particular index
    let index=1;
    name.splice(index, 0, "rahul");
    
//e. delete from a particular index
    name.splice(1,1);
    
    console.log(name);
}