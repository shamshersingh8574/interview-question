 
    let arr = ["Even", "Odd"];
    let no = prompt("Enter a number: ");
     
    document.write(arr[no % 2]);
