 
    
    
    var  number, Even_Sum = 0, Odd_Sum = 0;

    // var number=prompt("enter even or odd no");

    for(var i = 1; i <= 4; i++)
  {
  	if ( i%2 == 0 ) 
  	{
        Even_Sum = Even_Sum + i;
        console.log(Even_Sum);

    }

  	else
    
  	{
  		Odd_Sum = Odd_Sum + i;
        console.log(Odd_Sum);
	}
  }
