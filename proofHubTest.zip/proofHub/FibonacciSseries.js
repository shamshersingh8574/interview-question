// FibonacciSeries

    var i = 0, j = 1, k;
    while(i<15)
    {
        document.write(i + " , ");
        k = i+j;
        i = j;
        j = k;
    }

   
  
// var  j=1,k;
// for(var i=0; i<50; i++){
//     document.write(i , ", ");
//     k=i+j;
//     i=j;
//     j=k;
// }


// Q=>1
// let a=1, b=1, c;

// for( a = 0; a<=10; a++){

// document.write(a+" ,")

// c=a+b;
// a=b;
// b=c;

// }
