 
    const string = 'JavaScript was created by Brendan Eich in 1995 to give web pages a little more pep than the <blink> tag could provide. Today it has far more powerful uses and companies like Google and Facebook use JavaScript to build complex desktop-like web applications. With the launch of Node.js, It has also become one of the most popular languages for building server-side software. Today, even the web isn’t big enough to contain JavaScript’s versatility. I believe that you are already aware of these facts and this has made you land on this JavaScript Interview Questions article.';

    // const usingSplit = string.split('');
    // const usingSpread = [...string];
    const usingArrayFrom = Array.from(string);
    //const usingObjectAssign = Object.assign([], string);
    let n = usingArrayFrom.length;
    // let index = 0;
    let count = 0;
    var s = "";

    for (let i = 0; i < n; i++) {
        if (usingArrayFrom[i] == 'a') {
            s += i + " ";
            count++;
        }
    }
    console.log("index are- " + s);

    console.log("Total no of a - " + count);
