const name = ["sham", "Ram","Anamika","Syam singh"]
const age = [22,33,4,11,33,2,77,12]
const Class= ["bca","ba","llb"]

//   let index=2; 
//  name.splice(index,2,"neha","sita");
// console.log(name);


//e. delete from a particular index
// name.splice(2,2);
// console.log(name);
    
// var b= age.map((add)=>{
//     return add*2;
// })
// console.log(b);




//1. push pop add & remove right side data in array

//2. shift unshift remove & add left side data in array

//3. concat for use  add multiple array or string
//   const total = name.concat(age,Class);
//   console.log(total);

//4. join all array value ko ak me write krta hai
//   const j=name.join(", ")
// console.log(j); 

//5.  slice() iska use array me se kitna value chahiye  krne ke liye
//    const slis= age.slice(-2)
//    const slis= age.slice(2,4)
//    console.log(slis);

//6. isme 2,1 mins 2 no index pr name ko add krega and 1 no pr delete krega. isme add and delete dono sath me kr skte hai
//       let index=2; 
//    name.splice(index,1,"neha","sita");
//    console.log(name);

//7. Array.isArray(a) isme ye cheack krega array hai ya nhi. 
//   const a = Array.isArray(age);
//   console.log(a);

//8. isme serch krte hai ki value kis index pr hai start se check krega
//  const a = name.indexOf("Ram");
//  console.log(a);

//9. lastIndexOf("") isme last se index check krta hai
 
//10. yh string and numeric serch krta hai array me hai ki nhi hai to true return nhi to false 
// const a = name.includes("Ram");
// console.log(a);

//11. array ki value ko string me convert krta hai
// const a =age.toString();
// console.log(a);

//12. array ke andar kitne no of value hai use find krta hai length
// const a = age.length
// console.log(a);

//13. reduce method array ke sv value me kuchh calculation add krne ke liye kr skte hai
// const a = age.reduce((toatl,ages)=>{
//     return toatl+ages;
// })




//14. const age = [10,20,30,5,55,10,4,8,45]
   
//  const a= age.map((ag)=>{
//     return `${ag*2}`;
//  })
// // console.log(a);

// const b = a.sort((c,d)=>{
//     return `${d-c}`
// })

// // console.log(b);

// const a = age.filter(b=>b>20)
// console.log(a);

// 15.
// const sum = ()=>{
//     for (let i = 1; i <= 10; i++) {
//         setTimeout( () =>{
//           console.log(i)
//         }, i* 1000)
//       }
//   }
//   sum();

// 16. HOC EXM
// function add(a,b){
//     return a+b;
// }
// function highorder(d,c)
// {
//     return c(d,20)
// }
// console.log(highorder(30,add));

// 17. average 
// const a=[2,3,4];
// var b=a.reduce((ary,i)=>{
//     return ary+i;
// })
// var c=b/a.length;
// console.log(c);


// 18.
// let a1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
//   let b1 = a1.filter((c1) => {
//     return c1 % 2 === 0;
//   });
//   console.log(b1);

// 19. 1-index , 3- delete particular value ko insert delete update krna
// let a=[1,2,3,4,5,6]
// let b=a.splice(1,3);
// console.log(a);
// console.log(b);

// 20.find even values from array, make double of every element and find array length manually
// var a=[2,3,4,5,6,7,8];
// for(let i=0; i<=a.length; i++){
    
//     if(a[i]%2==0){
//         console.log(a[i]*2);

//     }

// }

